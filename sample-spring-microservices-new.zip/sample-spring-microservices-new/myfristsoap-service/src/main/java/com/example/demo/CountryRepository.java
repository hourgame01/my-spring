package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import jakarta.annotation.PostConstruct;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.spring.guides.gs_producing_web_service.Country;
import io.spring.guides.gs_producing_web_service.Currency;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

//import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

//import com.example.demo.Country;
//import com.example.demo.CountryRowMapper;

import jakarta.servlet.http.HttpServletRequest;

@Component
public class CountryRepository {
	private static final Map<String, Country> countries = new HashMap<>();
	
	private static final Logger logger = LoggerFactory.getLogger(MyFristSoap1Application.class);
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	//ClientThings client; 
	
	protected String getIpAddress() {
	    String ipAddress = request.getHeader("X-FORWARDED-FOR");
	    if (ipAddress == null) {
	        ipAddress = request.getRemoteAddr();
	    }
	    return ipAddress;
	}
	
	@PostConstruct
	public void initData() {
		Country spain = new Country();
		spain.setName("Spain");
		spain.setCapital("Madrid");
		spain.setCurrency(Currency.EUR);
		spain.setPopulation(46704314);
		spain.setSex("Xnxx");

		countries.put(spain.getName(), spain);

		Country poland = new Country();
		poland.setName("Poland");
		poland.setCapital("Warsaw");
		poland.setCurrency(Currency.PLN);
		poland.setPopulation(38186860);
		poland.setSex("xvideo");

		countries.put(poland.getName(), poland);

		Country uk = new Country();
		uk.setName("United Kingdom");
		uk.setCapital("London");
		uk.setCurrency(Currency.GBP);
		uk.setPopulation(63705000);
		uk.setSex("pornhub");

		countries.put(uk.getName(), uk);
	}
	
	public Country findByCountryName(String p_name) {

        //String sql = "SELECT name, population, capital, sex FROM country WHERE name = ?";
        String sql = "SELECT * FROM country WHERE name = ?";
        
        //return jdbcTemplate.queryForObject(sql, new Object[]{id}, new CustomerRowMapper());
        return jdbcTemplate.queryForObject(sql, new CountryRowMapper(), new Object[]{p_name} );
    }
	
	public List<Country> findAll2() {

        String sql = "SELECT * FROM country";

        List<Country> countries = jdbcTemplate.query(
                sql,
                new CountryRowMapper());

        return countries;
    }
	
	

	public Country findCountry(String name) {
		Assert.notNull(name, "The country's name must not be null");
		//return countries.get(name);
		Country xx = this.findByCountryName(name);
		System.out.println(xx.getCapital());
		
		logger.info("Info log message2 {}", xx.getCapital());
		logger.info("Info log message3 {}", getIpAddress());
		
		return xx;
	}
}