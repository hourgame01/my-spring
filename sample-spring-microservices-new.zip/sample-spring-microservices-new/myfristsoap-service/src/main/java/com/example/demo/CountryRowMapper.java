package com.example.demo;

import org.springframework.jdbc.core.RowMapper;

import io.spring.guides.gs_producing_web_service.Country;
import io.spring.guides.gs_producing_web_service.Currency;

//import jakarta.xml.bind.annotation.XmlEnum;
//import jakarta.xml.bind.annotation.XmlType;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CountryRowMapper implements RowMapper<Country>{
	@Override
    public Country mapRow(ResultSet rs, int rowNum) throws SQLException {

		Country country = new Country();
		//country.setID(rs.getInt("id"));
		country.setName(rs.getString("name"));
		country.setPopulation(rs.getInt("population"));
		country.setCapital(rs.getString("capital"));
		//country.setCurrency(rs.getString("currency"));
		//country.setCurrency(Currency.values()[rs.getInt("currency")]);
		country.setCurrency(Currency.valueOf(rs.getString("currency")));
		country.setSex(rs.getString("sex"));
		
        return country;

    }
}
