package com.bezkoder.springjwt.models;

import jakarta.persistence.*;

@Entity
@Table(name = "v_menu")
public class Menu {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="role_id")
	private Integer role_id;
	
	@Column(name="label")
	private String label;
	
	@Column(name="menu")
	private String menu;
	
	@Column(name="full_menu")	
	private String full_menu;
	
	public Integer getId() {
		return id;
	}

    public void setId(Integer id) {
    	this.id = id;
    }
	
	public String getLabel() {
		return label;
	}

    public void setLabel(String label) {
    	this.label = label;
    }
    
    public Integer getRoleId() {
		return role_id;
	}

    public void setRoleId(Integer role_id) {
    	this.role_id = role_id;
    }
    
    public String getMenu() {
		return menu;
	}

    public void setMenu(String menu) {
    	this.menu = menu;
    }
    
    public String getFullMenu() {
		return full_menu;
	}

    public void setFullMenu(String full_menu) {
    	this.label = full_menu;
    }
}
