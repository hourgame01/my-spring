const express = require("express");
const path = require("path");
const app = express();
const publicPath = path.join(__dirname, "..", "client/build");

// Require the upload middleware
const upload = require('./upload');
const myPdfKit = require('./pdfkit');

app.use(express.static(publicPath));


app.get("/*", function (req, res) {
	res.sendFile(path.join(publicPath, "index.html"));
});

// Set up a route for file uploads
app.post('/upload', upload.single('file'), (req, res) => {
	
	myPdfKit();
	
	// Handle the uploaded file
	res.json({ message: 'File uploaded successfully!' });
});

app.listen(process.env.PORT || 7070);