#ref:
https://spring.io/guides/gs/uploading-files/#initial
https://github.com/spring-guides/gs-uploading-files


#run:
$ mvnw spring-boot:run

#test:

curl -v -F file=home3.jpg -F upload="@home3.jpg" "http://localhost:8080/"

curl -v -F "upload=@\"D:/Projects/img/home3.jpg\"" "http://localhost:8080/"
D:\Projects\img

curl --form file="@home3.jpg" "http://localhost:8080/x"
curl --form file="@Untitled.jpg" "http://localhost:8080/x"
curl --form file="@song_post_d1.jpg" "http://localhost:8080/x"
curl --form file="@book.csv" "http://localhost:8080/x"
curl --form file="@song_post_d1.jpg" "http://localhost:8080"
curl --form file="D:\Projects\img\Untitled3.jpg" "http://localhost:8080/"

