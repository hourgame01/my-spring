package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;


import io.spring.guides.gs_producing_web_service.Country;

@SpringBootApplication
public class MyFristSoap1Application implements CommandLineRunner{
	
	private static final Logger logger = LoggerFactory.getLogger(MyFristSoap1Application.class);
	
	//private CountryRepository countryRepository;
	@Autowired
    JdbcTemplate jdbcTemplate;
   
    @Autowired
    CountryRepository countryRepository;

	public static void main(String[] args) {
		SpringApplication.run(MyFristSoap1Application.class, args);		
	}
	
	@Override
    public void run(String... args) {
		Country xx = countryRepository.findByCountryName("Spain");
		System.out.println(xx.getName());
		
		//logger.debug("Debug log message {}", xx.getName());
        logger.info("Info log message {}", xx.getName());
        //logger.error("Error log message {}", xx.getName());
        //logger.warn("Warn log message {}", xx.getName());
        //logger.trace("Trace log message {}", xx.getName());
		//jdbcTemplate.execute("CREATE TABLE customer2(" +
                //"id INT(10) NOT NULL AUTO_INCREMENT, name VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_520_ci', age INT(10) NULL DEFAULT NULL, created_date TIMESTAMP NULL DEFAULT NULL, PRIMARY KEY (`id`) USING BTREE) COLLATE='utf8mb4_unicode_520_ci' ENGINE=InnoDB AUTO_INCREMENT=1");
    
	}

}
