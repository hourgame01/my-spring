package com.bezkoder.springjwt.controllers;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;

import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bezkoder.springjwt.payload.request.LoginRequest;
import com.bezkoder.springjwt.payload.response.JwtResponse;
import com.bezkoder.springjwt.security.services.UserDetailsImpl;

import com.google.gson.Gson;

import jakarta.validation.Valid;

import com.bezkoder.springjwt.customer.Customer;
import com.bezkoder.springjwt.customer.CustomerRepository;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class TestController {
  @Autowired
  JdbcTemplate jdbcTemplate;
 
  @Autowired
  CustomerRepository customerRepository;
	
	
  @GetMapping("/all")
  public String allAccess() {
    return "Public Content.";
  }

  @GetMapping("/user")
  @PreAuthorize("hasRole('USER') or hasRole('MODERATOR') or hasRole('ADMIN')")
  public String userAccess() {
    return "User Content.";
  }

  @GetMapping("/mod")
  @PreAuthorize("hasRole('MODERATOR')")
  public String moderatorAccess() {
    return "Moderator Board.";
  }

  @GetMapping("/admin")
  @PreAuthorize("hasRole('ADMIN')")
  public String adminAccess() {
    return "Admin Board.";
  }
  
  @GetMapping("/datagrid8_getata.php")
  @PreAuthorize("hasRole('MODERATOR')")
  public String getDatagrid8() {
    return "{\"total\":\"28\",\"rows\":[{\"itemid\":\"EST-1\",\"productid\":\"FI-SW-01\",\"listprice\":\"16.50\",\"unitcost\":\"10.00\",\"status\":\"P\",\"attr1\":\"Large\"},{\"itemid\":\"EST-10\",\"productid\":\"K9-DL-01\",\"listprice\":\"18.50\",\"unitcost\":\"12.00\",\"status\":\"P\",\"attr1\":\"Spotted Adult Female\"},{\"itemid\":\"EST-11\",\"productid\":\"RP-SN-01\",\"listprice\":\"18.50\",\"unitcost\":\"12.00\",\"status\":\"P\",\"attr1\":\"Venomless\"},{\"itemid\":\"EST-12\",\"productid\":\"RP-SN-01\",\"listprice\":\"18.50\",\"unitcost\":\"12.00\",\"status\":\"P\",\"attr1\":\"Rattleless\"},{\"itemid\":\"EST-13\",\"productid\":\"RP-LI-02\",\"listprice\":\"18.50\",\"unitcost\":\"12.00\",\"status\":\"P\",\"attr1\":\"Green Adult\"},{\"itemid\":\"EST-14\",\"productid\":\"FL-DSH-01\",\"listprice\":\"58.50\",\"unitcost\":\"12.00\",\"status\":\"P\",\"attr1\":\"Tailless\"},{\"itemid\":\"EST-15\",\"productid\":\"FL-DSH-01\",\"listprice\":\"23.50\",\"unitcost\":\"12.00\",\"status\":\"P\",\"attr1\":\"With tail\"},{\"itemid\":\"EST-16\",\"productid\":\"FL-DLH-02\",\"listprice\":\"93.50\",\"unitcost\":\"12.00\",\"status\":\"P\",\"attr1\":\"Adult Female\"},{\"itemid\":\"EST-17\",\"productid\":\"FL-DLH-02\",\"listprice\":\"93.50\",\"unitcost\":\"12.00\",\"status\":\"P\",\"attr1\":\"Adult Male\"},{\"itemid\":\"EST-18\",\"productid\":\"AV-CB-01\",\"listprice\":\"193.50\",\"unitcost\":\"92.00\",\"status\":\"P\",\"attr1\":\"Adult Male\"}]}";
  }
    
  @PostMapping("/datagrid8_getata.php")
  @PreAuthorize("hasRole('MODERATOR')")
  public String getDatagrid8(@Valid @RequestBody Map<String,Object> body) {

	String s = body.get("page").toString();
	s += body.get("rows").toString();
	
	System.out.println("s");
	System.out.println(s);
	
	Customer findcustid = customerRepository.findByCustomerId(1);    
    System.out.println(findcustid.getName());
    
    
  //Use object instead of String as you want nested objects in output
    Map<String, Object> report = new HashMap<>();
    
    String highestRankedGame = "highestRankedGame";
    String userWithMostComments = "userWithMostComments";
    
    Integer total = 20;
    
    Map<Integer, Map<String,String>> x = new HashMap<>();
    Map<String,String> averageLikesPerGame = new HashMap<>();
    
    averageLikesPerGame.put("itemid","EST-1");
    averageLikesPerGame.put("productid","FI-SW-01");
    averageLikesPerGame.put("listprice","16.50");
    averageLikesPerGame.put("unitcost","10.00");
    averageLikesPerGame.put("status","P");
    averageLikesPerGame.put("attr1","Large");
    
    x.put(0, averageLikesPerGame);
    
    averageLikesPerGame.put("itemid","EST-2");
    averageLikesPerGame.put("productid","FI-SW-02");
    averageLikesPerGame.put("listprice","14.50");
    averageLikesPerGame.put("unitcost","11.00");
    averageLikesPerGame.put("status","P");
    averageLikesPerGame.put("attr1","Small");
    x.put(1, averageLikesPerGame);
    
    //report.put("highest_rated_game",highestRankedGame);
    //report.put("user_with_most_comments", userWithMostComments);
    report.put("total", total);
    report.put("rows", x);
    
    //String jsonReport = new JsonApplication().convertReportToJson(report);
    
    //System.out.println(jsonReport);
    
    
    // Create a new instance of Gson
    Gson gson = new Gson();
    String jsonReport = gson.toJson(report);
    
    //Creating a JSONObject object
    JSONObject jsonObject = new JSONObject();
    //JSONObject jsonObjectdesc = new JSONObject();
    JSONObject jsonObjectdesc2 = new JSONObject();
    JSONArray array3 = new JSONArray();
    
    
    /*jsonObjectdesc.put("itemid","EST-2");
    jsonObjectdesc.put("productid","FI-SW-02");
    jsonObjectdesc.put("listprice","14.50");
    jsonObjectdesc.put("unitcost","11.00");
    jsonObjectdesc.put("status","P");
    jsonObjectdesc.put("attr1","Small");    
    array3.add(jsonObjectdesc);    
    
    jsonObjectdesc2.put("itemid","EST-1");
    jsonObjectdesc2.put("productid","FI-SW-01");
    jsonObjectdesc2.put("listprice","16.50");
    jsonObjectdesc2.put("unitcost","10.00");
    jsonObjectdesc2.put("status","P");
    jsonObjectdesc2.put("attr1","Large");
    array3.add(jsonObjectdesc2);
    
    jsonObject.put("rows", array3);
    jsonObject.put("total", 2);*/
        
	Integer $page = body.get("page") != null ? (Integer) body.get("page") : 1;
	Integer $rows = body.get("rows") != null ? (Integer) body.get("rows") : 10;
	Integer $offset = ($page-1)*$rows;
    
    String sql = String.format("SELECT * FROM customer WHERE 1=1 LIMIT %2d, %2d", $offset,$rows);
       
    List<Customer> customers = new ArrayList<>();

    List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
    
    Integer row_total = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM customer WHERE 1=1", Integer.class);
    for (Map row : rows) {    	
        /*Customer obj = new Customer();

        obj.setID(((Integer) row.get("id")).intValue());
        //obj.setID(((Long) row.get("ID"))); no, ClassCastException
        obj.setName((String) row.get("name"));
        obj.setAge(((Integer) row.get("age")).intValue()); // Spring returns BigDecimal, need convert
        obj.setCreatedDate(((Timestamp) row.get("created_date")).toLocalDateTime());
        customers.add(obj);*/
        
    	JSONObject jsonObjectdesc = new JSONObject();
        jsonObjectdesc.put("id", ((Integer) row.get("id")).intValue());
        jsonObjectdesc.put("name", (String) row.get("name"));
        jsonObjectdesc.put("age", ((Integer) row.get("age")).intValue());
        jsonObjectdesc.put("created_date", (((Timestamp) row.get("created_date")).toLocalDateTime()).toString());
        
        array3.add(jsonObjectdesc);         
    }
    
    jsonObject.put("rows", array3);
    jsonObject.put("total", row_total);
    jsonObject.put("sql", sql);
    //jsonObject.put("$page", $page);
    //jsonObject.put("$rows", $rows);
	//jsonObject.put("$offset", $offset);

    //return s;
    //return jsonReport.toString();
    return jsonObject.toString();
  }
  
  
}
