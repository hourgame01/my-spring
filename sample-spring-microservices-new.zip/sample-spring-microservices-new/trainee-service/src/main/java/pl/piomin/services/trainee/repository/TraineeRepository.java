package pl.piomin.services.trainee.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import pl.piomin.services.trainee.model.Trainee;

public class TraineeRepository {

	private List<Trainee> trainees = new ArrayList<>();
	
	public Trainee add(Trainee trainee) {
		trainee.setId((long) (trainees.size()+1));
		trainees.add(trainee);
		return trainee;
	}
	
	public Trainee findById(Long id) {
		return trainees.stream()
				.filter(a -> a.getId().equals(id))
				.findFirst()
				.orElseThrow();
	}
	
	public List<Trainee> findAll() {
		return trainees;
	}
	
	public List<Trainee> findByDepartment(Long departmentId) {
		return trainees.stream()
				.filter(a -> a.getDepartmentId().equals(departmentId))
				.toList();
	}
	
	public List<Trainee> findByOrganization(Long organizationId) {
		return trainees.stream()
				.filter(a -> a.getOrganizationId().equals(organizationId))
				.toList();
	}
	
}
