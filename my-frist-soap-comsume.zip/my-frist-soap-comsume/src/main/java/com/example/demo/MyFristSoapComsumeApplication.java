package com.example.demo;

//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.consumingwebservice.wsdl.GetCountryResponse;

@SpringBootApplication
public class MyFristSoapComsumeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFristSoapComsumeApplication.class, args);
	}
	
	  @Bean
	  CommandLineRunner lookup(CountryClient quoteClient) {
	    return args -> {
	      String country = "Spain";

	      if (args.length > 0) {
	        country = args[0];
	      }
	      GetCountryResponse response = quoteClient.getCountryxx(country);
	      System.err.println(response.getCountry().getCurrency());
	      System.err.println(response.getCountry().getCapital());
	      System.err.println(response.getCountry().getSex());
	    };
	  }

}
