package com.bezkoder.springjwt.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class CustomerRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int save(Customer customer) {
        return jdbcTemplate.update(
                "insert into customer (name, age, created_date) values(?,?,?)",
                customer.getName(), customer.getAge(), LocalDateTime.now());
    }

    public Customer findByCustomerId(Integer id) {

        String sql = "SELECT * FROM customer WHERE id = ?";

        //return jdbcTemplate.queryForObject(sql, new Object[]{id}, new CustomerRowMapper());
        return jdbcTemplate.queryForObject(sql, new CustomerRowMapper(), new Object[]{id} );
    }

    public Customer findByCustomerId2(Integer id) {

        String sql = "SELECT * FROM customer WHERE id = ?";

        return (Customer) jdbcTemplate.queryForObject(sql, new Object[]{id}, new BeanPropertyRowMapper(Customer.class));

    }

    public Customer findByCustomerId3(Integer id) {

        String sql = "SELECT * FROM customer WHERE id = ?";

        return jdbcTemplate.queryForObject(sql, new Object[]{id}, (rs, rowNum) ->
                new Customer(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getTimestamp("created_date").toLocalDateTime()
                ));

    }

    public List<Customer> findAll() {

        String sql = "SELECT * FROM customer";

        List<Customer> customers = new ArrayList<>();

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

        for (Map row : rows) {
            Customer obj = new Customer();

            obj.setID(((Integer) row.get("id")).intValue());
            //obj.setID(((Long) row.get("ID"))); no, ClassCastException
            obj.setName((String) row.get("name"));
            obj.setAge(((Integer) row.get("age")).intValue()); // Spring returns BigDecimal, need convert
            obj.setCreatedDate(((Timestamp) row.get("created_date")).toLocalDateTime());
            customers.add(obj);
        }

        return customers;
    }

    public List<Customer> findAll2() {

        String sql = "SELECT * FROM customer";

        List<Customer> customers = jdbcTemplate.query(
                sql,
                new CustomerRowMapper());

        return customers;
    }

    public List<Customer> findAll3() {

        String sql = "SELECT * FROM customer";

        List<Customer> customers = jdbcTemplate.query(
                sql,
                new BeanPropertyRowMapper(Customer.class));

        return customers;
    }

    public List<Customer> findAll4() {

        String sql = "SELECT * FROM customer";

        return jdbcTemplate.query(
                sql,
                (rs, rowNum) ->
                        new Customer(
                                rs.getInt("id"),
                                rs.getString("name"),
                                rs.getInt("age"),
                                rs.getTimestamp("created_date").toLocalDateTime()
                        )
        );
    }

    public String findCustomerNameById(Integer id) {

        String sql = "SELECT name FROM customer WHERE id = ?";

        return jdbcTemplate.queryForObject(
                sql, new Object[]{id}, String.class);

    }

    public int count() {

        String sql = "SELECT COUNT(*) FROM customer";

        // queryForInt() is Deprecated
        // https://www.mkyong.com/spring/jdbctemplate-queryforint-is-deprecated/
        //int total = jdbcTemplate.queryForInt(sql);

        return jdbcTemplate.queryForObject(sql, Integer.class);

    }

}
