package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;

import jakarta.servlet.http.HttpServletRequest;

public class ClientThings {
	//@Autowired
	//private HttpServletRequest request;
	
	public String getIpAddress(HttpServletRequest request) {
	    String ipAddress = request.getHeader("X-FORWARDED-FOR");
	    if (ipAddress == null) {
	        ipAddress = request.getRemoteAddr();
	    }
	    return ipAddress;
	}

}
