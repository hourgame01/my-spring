package com.example.uploadingfiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class ProcessServiceImpl implements ProcessService {
	
	private static final Logger logger = LoggerFactory.getLogger(ProcessServiceImpl.class);

	@Async("processExecutor")
    @Override
    public void process() {
        logger.info("Received request to process in ProcessServiceImpl.process()");
        try {
            Thread.sleep(15 * 1000);
            logger.info("Processing complete");
        }
        catch (InterruptedException ie) {
            logger.error("Error in ProcessServiceImpl.process(): {}", ie.getMessage());
        }
    }
	
	@Async("processExecutor")
    @Override
    public void processReadExcel(String Filename) {
		Boolean flagStatus = false;
		
        logger.info("Received request to process in ProcessServiceImpl.process()");
        try {
            Thread.sleep(5 * 1000);
            
            List<List<String>> records = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader(Filename))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] values = line.split(",");
                                        
                    
                    
                    records.add(Arrays.asList(values));
                    
                    
                }
                
                System.out.println(records.get(0).toString());
                System.out.println(records.get(1).toString());
                System.out.println(records.get(2).toString());
                System.out.println(records.get(3).toString());
                System.out.println(records.get(4).toString());
                
                flagStatus = true;
                
                
            } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            
            logger.info("Processing complete");
        }
        catch (InterruptedException ie) {
            logger.error("Error in ProcessServiceImpl.process(): {}", ie.getMessage());
        }
    }
}
