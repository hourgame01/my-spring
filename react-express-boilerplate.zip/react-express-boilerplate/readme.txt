#ref:
https://rahul-pol.medium.com/boilerplate-code-for-web-app-using-react-js-and-express-js-in-7-steps-f21cc34a62c1

#purpose:
boilerplate for reactjs and express which mean both client/server are running together.

#install boilerplate:

$ mkdir react-express-boilerplate
$ cd react-express-boilerplate
##client:
$ npx create-react-app client
$ cd client
$ npm run build
##server:
$ cd ..
$ mkdir server
$ cd server
$ npm init -y
$ npm install express -S
##run first start for fresh boilerplate.
$ node index.js

#install:
##client
$ cd client
$ npm install
##server:
$ cd server
$ npm install

#run:
$ cd server
$ npm run server




