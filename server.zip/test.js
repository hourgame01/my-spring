const myPdfKit = require('./pdfkit');


myPdfKit('req.files');

