package com.bezkoder.springjwt.repository;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bezkoder.springjwt.customer.Customer;
import com.bezkoder.springjwt.models.Menu;

@Repository
public interface MenuRepository extends  JpaRepository<Menu, Long> {
	//List<Menu> findByMenu(int role_id);
	//List<Menu> findByRoleId(int role_id);
	
	//@Query("from v_menu t where t.role_id = :role_id")
	@Query(nativeQuery = true, value = "SELECT id, label, role_id, menu, full_menu FROM v_menu t WHERE label='Datagrid' AND t.role_id = :role_id LIMIT 1")
    public Optional<Menu> findByRoleId(@Param("role_id") int role_id);
	
	@Query(nativeQuery = true, value = "SELECT COUNT(*) FROM v_menu t LEFT JOIN roles r ON t.role_id = r.id WHERE r.name IN(:role_name)")
    public Integer findByRoleIdDetail(@Param("role_name") List<String> role_name);

  //Boolean existsByUsername(String username);

  //Boolean existsByEmail(String email);
}
/*public class MenuRepository {
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	
	public List<Menu> findByRoleId(int role_id) {

        String sql = "SELECT id, label, role_id, menu, full_menu FROM v_menu t WHERE t.role_id = "+ role_id;

        List<Menu> menus = new ArrayList<>();

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

        for (Map row : rows) {
        	Menu obj = new Menu();

            obj.setId(((Integer) row.get("id")).intValue());
            //obj.setID(((Long) row.get("ID"))); no, ClassCastException
            obj.setLabel((String) row.get("label"));
            obj.setMenu(((String) row.get("menu"))); // Spring returns BigDecimal, need convert
            obj.setFullMenu((String) row.get("full_menu"));
            //obj.setCreatedDate(((Timestamp) row.get("created_date")).toLocalDateTime());
            menus.add(obj);
        }

        return menus;
    }
	
}*/




