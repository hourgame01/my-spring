package com.bezkoder.springjwt.payload.request;

import jakarta.validation.constraints.NotBlank;

public class MenuRequest {
	@NotBlank
	private String label;
	
	@NotBlank
	private String menu;
	
	@NotBlank
	private Integer role_id;
	
	@NotBlank
	private String full_menu;

	public String getLabel() {
		return label;
	}

    public void setLabel(String label) {
    	this.label = label;
    }
    
    public Integer getRoleId() {
		return role_id;
	}

    public void setRoleId(Integer role_id) {
    	this.role_id = role_id;
    }
    
    public String getMenu() {
		return menu;
	}

    public void setMenu(String menu) {
    	this.menu = menu;
    }
    
    public String getFullMenu() {
		return full_menu;
	}

    public void setFullMenu(String full_menu) {
    	this.label = full_menu;
    }
}
