const PDFDocument = require('pdfkit');
const fs = require('fs');
const mySharpImg = require('./sharp_image');

const myPdfKit = async function(p_req, p_topic){
	// Create a document
	const doc = new PDFDocument();

	const pdfName = Date.now() + '-' + 'output.pdf';

	// Pipe its output somewhere, like to a file or HTTP response
	// See below for browser usage
	doc.pipe(fs.createWriteStream(pdfName));

	// Embed a font, set the font size, and render some text
	//doc
	//  .font('fonts/PalatinoBold.ttf')
	//  .fontSize(25)
	//  .text('Some text with an embedded font!', 100, 100);

	// Add an image, constrain it to a given size, and center it vertically and horizontally
	/*doc.image('./uploads/1694800991613-cute-puppies9.jpg', {
	  fit: [100, 100],
	  //align: 'left',
	  //valign: 'left'
	});
	doc.image('./uploads/1686494552023-Tutorials.png', {
	  fit: [100, 100],
	  //align: 'center',
	  //valign: 'center'
	});*/

	/*
	// Scale proprotionally to the specified width
	doc.image('./uploads/1694969630781-cute-puppies9.jpg', 0, 15, {width: 300})
	   .text('Proportional to width', 0, 0);



	// Fit the image within the dimensions
	doc.image('./uploads/1694969663220-home1.jpg', 320, 15, {fit: [100, 100]})
	   .rect(320, 15, 100, 100)
	   .stroke()
	   .text('Fit', 320, 0);

	// Fit the image in the dimensions, and center it both horizontally and vertically
	doc.image('./uploads/xx.jpg', 430, 15, {fit: [100, 100], align: 'center', valign: 'center'})
	   .rect(430, 15, 100, 100).stroke()
	   .text('Centered', 430, 0);


	// Stretch the image
	doc.image('./uploads/xx.jpg', 320, 145, {width: 200, height: 100})
	   .text('Stretch', 320, 130);
	*/

	//console.log(p_req);

    doc.fontSize(25).text(p_topic, 50, 20, {
        lineBreak: false,
        align: 'center',
        valign: 'center'
    });

    let myP1 = await mySharpImg(p_req[0].path);
    let myP2 = await mySharpImg(p_req[1].path);
    let myP3 = await mySharpImg(p_req[2].path);
    let myP4 = await mySharpImg(p_req[3].path);
    //console.log(myP1);

	//for(let i=0;i<p_req.length;i++){
		// Scale proprotionally to the specified width
		//doc.image('./uploads/1694969630781-cute-puppies9.jpg', 0, 15, {width: 300})
		doc.image(myP1, 0, 75, {width: 300, height: 230})
		   .fontSize(10).text(p_req[0].originalname, 0, 60);

		// Stretch the image
		//doc.image('./uploads/xx.jpg', 320, 10, {width: 300, height: 230})
		doc.image(myP2, 320, 70, {width: 300, height: 230})
		   .fontSize(10).text(p_req[1].originalname, 320, 60);
		   
		// Scale proprotionally to the specified width
		//doc.image('./uploads/1694969630781-cute-puppies9.jpg', 0, 315, {width: 300, height: 230})
		doc.image(myP3, 0, 375, {width: 300, height: 230})
		   .fontSize(10).text(p_req[2].originalname, 0, 360);

		// Scale proprotionally to the specified width
		//doc.image('./uploads/1694969630781-cute-puppies9.jpg', 320, 315, {width: 300, height: 230})
		doc.image(myP4, 320, 375, {width: 300, height: 230})
		   .fontSize(10).text(p_req[3].originalname, 320, 360);
	
	//}

	//remove image
	fs.unlinkSync(p_req[0].path);
	fs.unlinkSync(p_req[1].path);
	fs.unlinkSync(p_req[2].path);
	fs.unlinkSync(p_req[3].path);

    /*
	doc.addPage();
	
	// Scale proprotionally to the specified width
	doc.image('./uploads/1694969630781-cute-puppies9.jpg', 0, 15, {width: 300})
	   .text('Proportional to width', 0, 0);

	// Stretch the image
	doc.image('./uploads/xx.jpg', 320, 10, {width: 300, height: 230})
	   .text('Stretch', 320, 0);
	   
	// Scale proprotionally to the specified width
	doc.image('./uploads/1694969630781-cute-puppies9.jpg', 0, 315, {width: 300, height: 230})
	   .text('Proportional to width', 0, 300);

	// Scale proprotionally to the specified width
	doc.image('./uploads/1694969630781-cute-puppies9.jpg', 320, 315, {width: 300, height: 230})
	   .text('Proportional to width', 320, 300);



	// Add another page
	doc
	  .addPage()
	  .fontSize(25)
	  .text('Here is some vector graphics...', 100, 100);

	// Draw a triangle
	doc
	  .save()
	  .moveTo(100, 150)
	  .lineTo(100, 250)
	  .lineTo(200, 250)
	  .fill('#FF3300');

	// Apply some transforms and render an SVG path with the 'even-odd' fill rule
	doc
	  .scale(0.6)
	  .translate(470, -380)
	  .path('M 250,75 L 323,301 131,161 369,161 177,301 z')
	  .fill('red', 'even-odd')
	  .restore();

	// Add some text with annotations
	doc
	  .addPage()
	  .fillColor('blue')
	  .text('Here is a link!', 100, 100)
	  .underline(100, 100, 160, 27, { color: '#0000FF' })
	  .link(100, 100, 160, 27, 'http://google.com/');

	*/

	// Finalize PDF file
	doc.end();

	//remove pdf
    fs.unlinkSync(pdfName);
}

module.exports = myPdfKit;