const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();

// Require the upload middleware
const upload = require('./upload');
const myPdfKit = require('./pdfkit');


//const publicPath = path.join(__dirname, "..", "client/build");
const publicPath = path.join(__dirname, "client/build");

app.use(express.static(publicPath));


app.get("/*", function (req, res) {
	res.sendFile(path.join(publicPath, "index.html"));
});

// Set up a route for file uploads
app.post('/multiupload', upload.array('file', 5), async function(req, res) {
	
	//console.log(res.files );
	//console.log(req.files  );
	console.log(req.body  );
	//console.log(req.body   );
	
	await myPdfKit(req.files, req.body.topic);
	
	// Handle the uploaded file
	//res.json({ message: 'File uploaded successfully!' });
	
	//var file = __dirname + '/output.pdf';
	var file = './output.pdf';
	//console.log(file);

	var filename = path.basename(file);
	//var mimetype = mime.getType(file);

	res.setHeader('Content-disposition', 'attachment; filename=' + filename);
	res.setHeader('Content-type', 'application/pdf');

	var filestream = fs.createReadStream(file);
	filestream.pipe(res);
	/*fs.readFile(file, (err,data)=>{
        if(err){
            console.log(err);
        }else {
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', 'attachment; filename=your_file_name_for_client.pdf');

            //res.send(data);
            //res.download("./output.pdf");
        }
    }) ;*/
	
});


// Set up a route for file uploads
app.post('/upload', upload.single('file'), (req, res) => {
	
	myPdfKit();
	
	// Handle the uploaded file
	res.json({ message: 'File uploaded successfully!' });
});

app.listen(process.env.PORT || 7070);