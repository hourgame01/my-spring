#ref:
https://github.com/bezkoder/spring-boot-spring-security-jwt-authentication
https://www.bezkoder.com/spring-boot-jwt-authentication/




#install:



#run:
$ mvn spring-boot:run



#sql:
SELECT COUNT(*)
FROM v_menu t
LEFT JOIN roles r
ON t.role_id = r.id
WHERE r.name IN('');

#SELECT * FROM v_menu;
SELECT id, label, role_id, menu, full_menu 
FROM v_menu t
LIMIT 1;


SELECT t.label, t.role_id,
t.menu, 
GROUP_CONCAT(DISTINCT t.full_menu ORDER BY t.full_menu SEPARATOR', ') full_menu
FROM roles_details t 
WHERE role_id=2
GROUP BY t.label, t.role_id, t.menu; #,t.full_menu;

SELECT t.label, 
t.menu, 
GROUP_CONCAT(DISTINCT t.full_menu ORDER BY t.full_menu SEPARATOR', ') full_menu
FROM roles_details t 
WHERE role_id=2
GROUP BY t.label, t.menu; #,t.full_menu;


CREATE OR REPLACE VIEW v_menu AS
SELECT t.id, t.label, t.role_id,
t.menu, 
GROUP_CONCAT(DISTINCT t.full_menu ORDER BY t.full_menu SEPARATOR', ') full_menu
FROM roles_details t 
WHERE role_id=2
GROUP BY t.id, t.label, t.role_id, t.menu; #,t.full_menu;
