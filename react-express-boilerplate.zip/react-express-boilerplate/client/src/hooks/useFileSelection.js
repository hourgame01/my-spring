import { useState } from 'react';
import axios, {isCancel, AxiosError} from 'axios';


const useFileSelection = () => {
  const [selectedFiles, setSelectedFiles] = useState([]);

  const addFile = (file) => {
	  
	console.log(file);
	
    setSelectedFiles((currentSelection) => [...currentSelection, file]);
  };

  const removeFile = (file) => {
    setSelectedFiles((currentSelection) => {
      const newSelection = currentSelection.slice();
      const fileIndex = currentSelection.indexOf(file);
      newSelection.splice(fileIndex, 1);
      return newSelection;
    });
  };
  
  const shooFile2 = (file) => {
    console.log('file');
    setSelectedFiles((currentSelection) => {
      console.log(currentSelection);
	  
	  const formData = new FormData();
	  formData.append("file", currentSelection[0]);
	  
	  axios.post('http://localhost:7070/upload', formData, {
		headers: {
          "Content-Type": "multipart/form-data",
          "x-rapidapi-host": "file-upload8.p.rapidapi.com",
          "x-rapidapi-key": "your-rapidapi-key-here",
        },
	  })
	  .then(function (response) {
		console.log(response);
	  })
	  .catch(function (error) {
		console.log(error);
	  });
	  
	  return currentSelection;
    });
  };	

  return [addFile, removeFile, shooFile2];
};

export default useFileSelection;
