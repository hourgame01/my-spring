package com.baeldung.extensions.controller;

public record Greeting(long id, String content) { }

