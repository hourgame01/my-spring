package com.example.uploadingfiles;

public interface ProcessService {
	
	public void process();
	public void processReadExcel(String Filename);

}
