#ref:
https://github.com/bezkoder/spring-boot-spring-security-jwt-authentication
https://www.bezkoder.com/spring-boot-jwt-authentication/




#install:



#run:
$ mvn spring-boot:run