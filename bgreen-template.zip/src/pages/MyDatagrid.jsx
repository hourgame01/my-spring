import React from 'react';
import { DataGrid, GridColumn, Label, ComboBox, NumberBox, CheckBox, TextBox, Tooltip, LinkButton, Dialog, FormField, Form } from 'rc-easyui';

import { validateURL } from "../helpers/sanitizer";


//import './App.css';

class MyDatagrid extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
		//title: 'Datagrid',	
		rownumbers: true, 
		total: 0,
		pageSize: 10,
		//data: this.getData(10000), //local
		data: [], //remote
		pageNumber: 1,
		loading: false,
	    sort: '',
        order: '',
		pagePosition: "bottom",
		pageOptions: {
			layout: ['list', 'sep', 'first', 'prev', 'sep', 'manual', 'sep', 'next', 'last', 'sep', 'refresh', 'info']
		},
		options: [
			{ value: "bottom", text: "Bottom" },
			{ value: "top", text: "Top" },
			{ value: "both", text: "Both" }
		],
		
    };
	
	this.myform = {
      user: {
        name: null,
        email: null,
        hero: null,
        accept: true
      },
      rules: {
        name: ["required", "length[5,10]"],
        email: "email",
        hero: "required"
      },
      heroes: [
        { value: 11, text: "Mr. Nice" },
        { value: 12, text: "Narco" },
        { value: 13, text: "Bombasto" },
        { value: 14, text: "Celeritas" },
        { value: 15, text: "Magneta" },
        { value: 16, text: "RubberMan" },
        { value: 17, text: "Dynama" },
        { value: 18, text: "Dr IQ" },
        { value: 19, text: "Magma" },
        { value: 20, text: "Tornado" }
      ]
    }
  }
  //datagrid local data
  getData(total) {
    let data = [];
    for (let i = 1; i <= total; i++) {
      let amount = Math.floor(Math.random() * 1000);
      let price = Math.floor(Math.random() * 1000);
      data.push({
        inv: "Inv No " + i,
        name: "Name " + i,
        amount: amount,
        price: price,
        cost: amount * price,
        note: "Note " + i
      });
    }
    return data;
  }
  //datagrid remote data
  fetchData() {
    const { pageNumber, sort, order } = this.state;
	
	//get JWT token
	let mytoken = localStorage.getItem("token");
	
	//get conf
	//const config = {
    //  //credentials: 'include',
    //  //method: 'post',
    //  method: 'get',
    //  mode: 'cors',
    //  headers: {
    //    'Accept': 'application/json, text/plain, */*',
    //    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
    //    'Authorization': `Bearer ${mytoken}`,
    //  },
    //  //body: `page=${pageNumber}&rows=10&sort=${sort}&order=${order}`
    //  //body: `page=${pageNumber}&rows=10`
    //  //body: `{"page":${pageNumber},"rows":10}`
    //};
	
	//post conf
    const config = {
      //credentials: 'include',
      method: 'post',
      //method: 'get',
      mode: 'cors',
      headers: {
        'Accept': 'application/json, text/plain, */*',
        //'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Content-Type': 'application/json;charset=utf-8',
        'Authorization': `Bearer ${mytoken}`,
      },
      //body: `page=${pageNumber}&rows=10&sort=${sort}&order=${order}`
      //body: `page=${pageNumber}&rows=10`
      body: `{"page":${pageNumber},"rows":10}`
    };
    //const url = 'https://www.jeasyui.com/demo/main/datagrid8_getdata.php';
	const u = 'http://localhost:8080/api/test/datagrid8_getata.php';
    const url = validateURL(u)? u : '';
    this.setState({ loading: true })
    fetch(url, config).then(res => {
	  console.log(res);
      return res.json();
    }).then(data => {
	  console.log(data);	
      this.setState({
        total: parseInt(data.total, 10),
        data: data.rows,
        loading: false
      })
    })
  }
  handlePageChange({ pageNumber, refresh }) {
    if (refresh) {
      this.fetchData();
    } else {
      this.setState({ pageNumber: pageNumber }, () => {
        this.fetchData();
      })
    }
  }
  handleChange(name, value) {
    let user = Object.assign({}, this.state.user);
    user[name] = value;
    this.setState({ user: user })
  }
  handleSubmit() {
    this.form.validate(errors => {
      // ...
    })
  }
  render() {
	const { user, rules, heroes } = this.myform;
	  
    return (
      <div>
        <h2>Pagination Layout</h2>
        <div style={{ marginBottom: 10 }}>
          <Label htmlFor="c1">Pager on: </Label>
          <ComboBox inputId="c1" style={{ width: 120 }}
            data={this.state.options}
            editable={false}
            panelStyle={{ height: 'auto' }}
            value={this.state.pagePosition}
            onChange={(value) => this.setState({ pagePosition: value })}
          />
        </div>
		
		<Dialog
          title="Toolbar and Button"
          style={{ width: 600, height: 500 }}
          bodyCls="f-column"
          //modal
		  draggable
          //resizable
          ref={ref => this.dlg = ref}
        >
			<div className="dialog-toolbar">
				<LinkButton iconCls="icon-edit" plain>Edit</LinkButton>
				<LinkButton iconCls="icon-help" plain>Help</LinkButton>
			</div>
			<div className="f-full">				
				<h2 style={{ textAlign: 'center', margin: '20px 0', fontSize: '20px' }} >Validate Form</h2>
				<Form
				  ref={ref => this.form = ref}
				  style={{maxWidth:500}}
				  model={user}
				  rules={rules}
				  labelWidth={120}
				  labelAlign="right"
				  onChange={this.handleChange.bind(this)}
				>
				  <FormField name="name" label="Name:">
					<TextBox></TextBox>
				  </FormField>
				  <FormField name="email" label="Email:">
					<TextBox></TextBox>
				  </FormField>
				  <FormField name="hero" label="Select a hero:">
					<ComboBox data={heroes}></ComboBox>
				  </FormField>
				  <FormField name="accept" label="Accept Me:">
					<CheckBox checked={user.accept}></CheckBox>
				  </FormField>
				  <FormField style={{ marginLeft: 120 }}>
					<LinkButton onClick={this.handleSubmit.bind(this)}>Submit</LinkButton>
				  </FormField>
				</Form>
				
				
			</div>
			<div className="dialog-button">
				<LinkButton style={{ width: 80 }}>Save</LinkButton>
				<LinkButton style={{ width: 80 }} onClick={() => this.dlg.close()} >Close</LinkButton>
			</div>
        </Dialog>
		
        <DataGrid
			title="Datagrid"
			ref={ref => this.datagrid = ref}
			style={{ height: 250 }}
			pagination
		    total={this.state.total}
            data={this.state.data}
			pageSize={this.state.pageSize}
			pageNumber={this.state.pageNumber}
			loading={this.state.loading}
			lazy
			onPageChange={this.handlePageChange.bind(this)}
			{...this.state}
			//clickToEdit
			//editMode="row"
			toolbar={() => (
				<div style={{ padding: 4 }}>
				<LinkButton iconCls="icon-add" plain onClick={() => this.dlg.open()} >Add</LinkButton>
				<LinkButton iconCls="icon-save" plain >Save</LinkButton>
				<LinkButton iconCls="icon-cancel" plain >Cancel</LinkButton>
				</div>
			)}
			//onEditEnd={this.handleRowEditEnd.bind(this)}
			//onEditCancel={this.handleRowEditCancel.bind(this)}
        >
		  <GridColumn field="rn" align="center" width="30px"
            cellCss="datagrid-td-rownumber"
            render={({rowIndex}) => (
              <span>{rowIndex+1}</span>
            )}
          />	
          {/*<GridColumn field="inv" title="Inv No"></GridColumn>
          <GridColumn field="name" title="Name"></GridColumn>
          <GridColumn field="amount" title="Amount" align="right"></GridColumn>
          <GridColumn field="price" title="Price" align="right"></GridColumn>
          <GridColumn field="cost" title="Cost" align="right"></GridColumn>
          <GridColumn field="note" title="Note"></GridColumn>*/}
		  {/*<GridColumn field="itemid" title="Item ID" sortable></GridColumn>
          <GridColumn field="productid" title="Product" sortable></GridColumn>
          <GridColumn field="listprice" title="List Price" align="right" sortable></GridColumn>
          <GridColumn field="unitcost" title="Unit Cost" align="right" sortable></GridColumn>
          <GridColumn field="attr1" title="Attribute" width="30%"></GridColumn>*/}
		  <GridColumn field="name" title="Name" sortable></GridColumn>
          <GridColumn field="age" title="Age" sortable></GridColumn>
          <GridColumn field="created_date" title="Created Date" align="right" sortable></GridColumn>          
        </DataGrid>
      </div>
    );
  }
}

export default MyDatagrid;
