#ref:
https://www.codejava.net/frameworks/spring-boot/email-sending-tutorial
https://github.com/codejava-official/spring-boot-email-sending

#purpose:
send email via gmail, outlook

#install:
$ mvn spring-boot:run

#run:
Run as -> Spring boot app

#setup:
##gmail(sender)
###ref:https://www.tothenew.com/blog/step-by-step-guide-sending-emails-in-spring-boot/
go to gmail -> manage your google account -> security -> 2-Step verification -> App Passwords(you may try to save first, then back to 2-step verification to check below)
-> then fill `application.properties`
spring.mail.password=<random_code_after_set_in_app_password>

##outlook
setting(top right) -> Sync email -> Let devices and apps use POP(yes) 
###server setting below
####POP setting
Server name: outlook.office365.com
Port: 995
Encryption method: TLS
####IMAP setting
Server name: outlook.office365.com
Port: 993
Encryption method: TLS
####SMTP setting
Server name: smtp.office365.com
Port: 587
Encryption method: STARTTLS
-> then fill `application.properties`
spring.mail.password=<your_email_password>

