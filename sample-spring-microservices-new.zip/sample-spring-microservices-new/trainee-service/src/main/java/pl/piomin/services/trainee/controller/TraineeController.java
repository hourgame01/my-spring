package pl.piomin.services.trainee.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import pl.piomin.services.trainee.model.Trainee;
import pl.piomin.services.trainee.repository.TraineeRepository;

@RestController
public class TraineeController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TraineeController.class);
	
	@Autowired
	TraineeRepository repository;
	
	@PostMapping("/")
	public Trainee add(@RequestBody Trainee trainee) {
		LOGGER.info("Trainee add: {}", trainee);
		return repository.add(trainee);
	}
	
	@GetMapping("/{id}")
	public Trainee findById(@PathVariable("id") Long id) {
		LOGGER.info("Trainee find: id={}", id);
		return repository.findById(id);
	}
	
	@GetMapping("/")
	public List<Trainee> findAll() {
		LOGGER.info("Trainee find");
		return repository.findAll();
	}
	
	@GetMapping("/department/{departmentId}")
	public List<Trainee> findByDepartment(@PathVariable("departmentId") Long departmentId) {
		LOGGER.info("Trainee find: departmentId={}", departmentId);
		return repository.findByDepartment(departmentId);
	}
	
	@GetMapping("/organization/{organizationId}")
	public List<Trainee> findByOrganization(@PathVariable("organizationId") Long organizationId) {
		LOGGER.info("Trainee find: organizationId={}", organizationId);
		return repository.findByOrganization(organizationId);
	}
	
}
