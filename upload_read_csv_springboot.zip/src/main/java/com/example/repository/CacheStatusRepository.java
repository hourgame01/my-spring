package com.example.repository;

/*
import org.springframework.data.repository.CrudRepository;

import com.example.model.CacheStatus;

public interface CacheStatusRepository extends CrudRepository<CacheStatus, Integer> {

}
*/