import { useState } from 'react';
import axios, {isCancel, AxiosError} from 'axios';
import fileDownload from 'js-file-download';

const useFileSelection = () => {
  const [selectedFiles, setSelectedFiles] = useState([]);
  //const [compressedFile, setCompressedFile] = useState(null);

  const addFile = (file) => {
	  
	//console.log('addFile');
	
    setSelectedFiles((currentSelection) => [...currentSelection, file]);
  };

  const removeFile = (file) => {
    setSelectedFiles((currentSelection) => {
      const newSelection = currentSelection.slice();
      const fileIndex = currentSelection.indexOf(file);
      newSelection.splice(fileIndex, 1);
      return newSelection;
    });
  };

  const shooFile2 = (event, file) => {
    console.log(event);
    console.log('file');
    setSelectedFiles((currentSelection) => {
      console.log(currentSelection);
	  
	  const formData = new FormData();
	  //single file
	  //formData.append("file", currentSelection[0]);
	  
	  console.log('multi1 ');

	  //multi files
	  //formData.append("file", currentSelection[0], "xxx");
	  formData.append("file", currentSelection[0]);
	  formData.append("file", currentSelection[1]);
	  formData.append("file", currentSelection[2]);
	  formData.append("file", currentSelection[3]);
	  
	  console.log('multi2 ');
	  event.target.innerText = 'Downloading';
	  event.target.disable = true;

	  const topic = document.getElementById('topic').value;
	  formData.append("topic", topic);
	  //console.log(topic);
	  //return;

	  //axios.post('http://localhost:7070/upload', formData, {
	  axios.post('http://localhost:7070/multiupload',
	    formData,
	    {
		headers: {
          "Content-Type": "multipart/form-data",
          "x-rapidapi-host": "file-upload8.p.rapidapi.com",
          "x-rapidapi-key": "your-rapidapi-key-here",
        },
        responseType: 'blob', // important
	  })
	  .then(function (response) {
		console.log(response);
		fileDownload(response.data, 'filename.pdf');
		event.target.innerText = 'Submit';
        event.target.disable = false;

	  })
	  .catch(function (error) {
		console.log(error);
	  });
	  
	  return currentSelection;
    });
  };	

  return [addFile, removeFile, shooFile2];
};

export default useFileSelection;
