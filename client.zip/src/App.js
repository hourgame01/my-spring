import './App.css';
import { Button, Card, Input, Select, Space } from 'antd';
import DragAndDrop from './components/DragAndDrop';
import useFileSelection from './hooks/useFileSelection';
import fireFiles from './hooks/fireFiles';

const App = () => {
  const [addFile, removeFile, shooFile2] = useFileSelection();
  const [shootFile] = fireFiles();
  
  console.log(addFile);

  return (
    <div style={{ margin: '1%', 'text-align': 'center' }}>
      <Card
        style={{ margin: 'auto', width: '50%' }}
        actions={[<Button type="primary" onClick={shooFile2} >Submit</Button>]}
      >
        <DragAndDrop addFile={addFile} removeFile={removeFile} />
      </Card>
      <Input style={{ margin: 'auto', width: '50%', 'text-align': 'center' }} placeholder="Topic" id="topic" />
      {/*<Space.Compact style={{ width: '50%' }}>
        <Input defaultValue="Combine input and button" />
        <Button type="primary">Submit</Button>
      </Space.Compact>*/}
    </div>
  );
};

export default App;
