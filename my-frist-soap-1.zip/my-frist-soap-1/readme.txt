#ref:
https://spring.io/guides/gs/producing-web-service/



#install:



#run:
##mvn run:
$ mvnw spring-boot:run
##build jar file
$ mvnw clean package
$ java -jar target/<jar>.jar





