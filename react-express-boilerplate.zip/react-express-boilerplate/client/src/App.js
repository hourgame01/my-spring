import './App.css';
import { Button, Card } from 'antd';
import DragAndDrop from './components/DragAndDrop';
import useFileSelection from './hooks/useFileSelection';
import fireFiles from './hooks/fireFiles';

const App = () => {
  const [addFile, removeFile, shooFile2] = useFileSelection();
  const [shootFile] = fireFiles();
  
  console.log(addFile);

  return (
    <div style={{ margin: '1%' }}>
      <Card
        style={{ margin: 'auto', width: '50%' }}
        actions={[<Button type="primary" onClick={shooFile2} >Submitx</Button>]}
      >
        <DragAndDrop addFile={addFile} removeFile={removeFile} />
      </Card>
    </div>
  );
};

export default App;
