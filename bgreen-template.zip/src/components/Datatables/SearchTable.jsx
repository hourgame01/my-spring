import React from "react";
import Input from "../../components/Input";

function SearchTable(props) {
  return (
    <>
      <Input {...props} />
    </>
  );
}

export default SearchTable;
