import { useState } from 'react';
import axios, {isCancel, AxiosError} from 'axios';
import fileDownload from 'js-file-download';

const useFileSelection = () => {
  const [selectedFiles, setSelectedFiles] = useState([]);
  //const [compressedFile, setCompressedFile] = useState(null);

  const addFile = (file) => {
	console.log('addFile');
	console.log(file);
    setSelectedFiles((currentSelection) => [...currentSelection, file]);
  };

  const removeFile = (file) => {
    setSelectedFiles((currentSelection) => {

      //const found = currentSelection.find((element) => element.uid > 10);
      for(let i=0;i<currentSelection.length;i++){
        console.log(currentSelection[i].uid);

        if(currentSelection[i].uid==file.uid){
          currentSelection.splice(i, 1);
        }
      }

      console.log('currentSelection');
      console.log(file);
      console.log(currentSelection);
      const newSelection = currentSelection.slice();
      //const fileIndex = currentSelection.indexOf(file);
      //console.log(fileIndex);
      //newSelection.splice(fileIndex, 1);
      //console.log(newSelection);
      return newSelection;
    });
  };

  const shooFile2 = (event, file) => {
    console.log(event);
    console.log('file');
    console.log(file);
    setSelectedFiles((currentSelection) => {
      let f_err = false;

      console.log(currentSelection);
	  
	  const formData = new FormData();
	  //single file
	  //formData.append("file", currentSelection[0]);
	  
	  console.log('multi1 ');

	  //validation on files
	  if(currentSelection.length > 4 || currentSelection.length < 4){
	    console.log(document.getElementById('result'));
	    //document.getElementById('result').style.display = 'block';
	    //document.getElementById('result_text').innerText = 'files must be 4';
	    document.getElementById('err').value = 'files must be 4';
	    f_err = true;
	    //return;
	  }

	  const topic = document.getElementById('topic').value;

	  //validation on topic
      if(topic == ''){
        //document.getElementById('result').style.display = 'block';
        //document.getElementById('result_text').innerText = 'Topic cannot be emptied';
        document.getElementById('err').value = 'Topic cannot be emptied';
        f_err = true;
        //return;
      }

	  //console.log(topic);
	  //return;

      if(!f_err){

        console.log('multi2 ');

        //multi files
        //formData.append("file", currentSelection[0], "xxx");
        formData.append("file", currentSelection[0]);
        formData.append("file", currentSelection[1]);
        formData.append("file", currentSelection[2]);
        formData.append("file", currentSelection[3]);

        console.log(event);

        //disable button
        event.target.innerText = 'Downloading';
        event.target.disable = true;
        event.target.disabled = true;


        //append topic data.
        formData.append("topic", topic);

        //axios.post('http://localhost:7070/upload', formData, {
        axios.post('http://localhost:7070/multiupload',
          formData,
          {
          headers: {
            "Content-Type": "multipart/form-data",
            "x-rapidapi-host": "file-upload8.p.rapidapi.com",
            "x-rapidapi-key": "your-rapidapi-key-here",
          },
          responseType: 'blob', // important
        })
        .then(function (response) {
          console.log(response);
          fileDownload(response.data, Date.now() + '-' + 'filename.pdf');
          event.target.innerText = 'Submit';
          event.target.disable = false;
          event.target.disabled = false;

        })
        .catch(function (error) {
          console.log(error);
        });
	  }
	  
	  return currentSelection;
    });

  };	

  return [addFile, removeFile, shooFile2];
};

export default useFileSelection;
