import { useState } from 'react';

const fireFiles = () => {
  
  const shootFile = (file) => {
	console.log(file);
	

	console.log('shoot');
  };

  return [shootFile];
};

export default fireFiles;
