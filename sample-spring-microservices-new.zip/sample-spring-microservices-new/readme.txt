#ref:
https://piotrminkowski.com/2023/03/13/microservices-with-spring-boot-3-and-spring-cloud/
https://github.com/piomin/sample-spring-microservices-news

#purpose:
microservice spring boot with(consider to use kubernetes for microservice): 
 - global config service: store global config which any service will take it. (consider to lower its priority as any new register service, will require restart all.)
 - discovery service(eureka): dicover any services that are connecting(any services will be connected to discovery service), and some info. (http://localhost:8061/)
 - api gateway service: any api core services will be access through gateway here. (consider to ban any direct access to core service)
 - core services:
   - employee-service
   - department-service
   - organization-service
   - trainee-service (my new registration service)
     - i create it manually(consider use mvn for project creation later) by clone `employee-service`(consider to integrate real process of trainee such as trainnee under which employee, job limit, level).
	   after that, we register it under `config-service`(remember to restart it after change). add new `trainee-service.yml`. add route under `gateway-service.yml`.(after start up service, you have to wait around 5mn for serice fully up, why require so many minute?)
   - myfristsoap-service (my new registration service)
 - zipkin service(app): trace log for any access to services.
 
 
 
#run:
##1:
$ cd D:\Projects\Spring\workspace-spring-tool-suite-4-4.19.0.RELEASE\sample-spring-microservices-new\config-service
$ mvn spring-boot:run
##2:
$ cd D:\Projects\Spring\workspace-spring-tool-suite-4-4.19.0.RELEASE\sample-spring-microservices-new\discovery-service
$ mvn spring-boot:run
##3:
$ cd D:\Projects\Spring\workspace-spring-tool-suite-4-4.19.0.RELEASE\sample-spring-microservices-new\gateway-service
$ mvn spring-boot:run
##4 (our core services):
$ cd D:\Projects\Spring\workspace-spring-tool-suite-4-4.19.0.RELEASE\sample-spring-microservices-new\department-service
$ mvn spring-boot:run
$ cd D:\Projects\Spring\workspace-spring-tool-suite-4-4.19.0.RELEASE\sample-spring-microservices-new\employee-service
$ mvn spring-boot:run
$ cd D:\Projects\Spring\workspace-spring-tool-suite-4-4.19.0.RELEASE\sample-spring-microservices-new\organization-service
$ mvn spring-boot:run
$ cd D:\Projects\Spring\workspace-spring-tool-suite-4-4.19.0.RELEASE\sample-spring-microservices-new\trainee-service
$ mvn spring-boot:run
$ cd D:\Projects\Spring\workspace-spring-tool-suite-4-4.19.0.RELEASE\sample-spring-microservices-new\myfristsoap-service
$ mvn spring-boot:run
##5:
###it located at our php-ubuntu(192.168.231.128)
$ sudo docker run -d --name zipkin -p 9411:9411 openzipkin/zipkin
####up container if not yet up
$ sudo docker run "/zipkin"
####check container 
$ sudo docker ps


#test:
##see our services detail(eureka)
http://localhost:8061/
##swagger(api generator)
http://localhost:8060/webjars/swagger-ui/index.htm
##zipkin(trace log)
http://192.168.231.128:9411/zipkin
##curl
###note: dont forget slash at the end. must include it.
###still something wrong with their route and code, change at our `trainee` service.
$ curl http://localhost:8060/employee/
$ curl http://localhost:8060/trainee/
$ curl http://localhost:8060/department/organization/1
$ curl http://localhost:8060/department/organization/1/with-employees
$ curl http://localhost:8060/organization/
$ curl http://localhost:8060/organization/1/with-departments
##soap
http://localhost:8060/myfristsoap/ws/countries.wsdl





