import './App.css';
import { PageHeader, Result, Typography, Button, Card, Input, Select, Space } from 'antd';
import DragAndDrop from './components/DragAndDrop';
import useFileSelection from './hooks/useFileSelection';
import fireFiles from './hooks/fireFiles';

const { Paragraph, Text } = Typography;

const App = () => {
  const [addFile, removeFile, shooFile2] = useFileSelection();
  const [shootFile] = fireFiles();
  
  console.log(addFile);
  console.log('addFile');
  console.log(process.env.SERVER_MULTI_UPLOAD_API);

  return (
    <div style={{ margin: '1%', 'text-align': 'center' }}>
      <PageHeader
          style={{ margin: 'auto', width: '50%' }}
          className="site-page-header"
          //onBack={() => null}
          title="Title"
          subTitle="PDF with image compression"
        />
      <Card
        style={{ margin: 'auto', width: '50%' }}
        actions={[<Button type="primary" onClick={shooFile2} >Submit</Button>]}
      >
        <DragAndDrop addFile={addFile} removeFile={removeFile} />
      </Card>
      <Input style={{ margin: 'auto', width: '50%', 'text-align': 'center' }} placeholder="Topic" id="topic" />
      <br/>
      <Input style={{ margin: 'auto', width: '50%', 'text-align': 'center' }} placeholder="xx" id="err" />
      {/*<Space.Compact style={{ width: '50%' }}>
        <Input defaultValue="Combine input and button" />
        <Button type="primary">Submit</Button>
      </Space.Compact>*/}

      <Result
          id="result"
          style={{ display: 'none'}}
          status="error"
          title="Submission Failed"
          subTitle="Please check and modify the following information before resubmitting."
          extra={[
            <Text
              id="result_text"
            >
              The content you submitted has the following error:
            </Text>
          ]}
        >
      </Result>
    </div>
  );
};

export default App;
