// ️ default export
//export default function SmallButton() {
//  return <button>Small</button>;
//}

// named export
export const validateURL = (p_url) => {
	const parsed = new URL(p_url)
	return ['https:', 'http:'].includes(parsed.protocol);	
};

export const validateURL2 = (p_url) => {
	const parsed = new URL(p_url)
	return ['https:', 'http:'].includes(parsed.protocol);	
};
