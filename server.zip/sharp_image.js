const sharp = require('sharp');

const mySharpImg = async function(p_img){
    //console.log('p_img =');
    //console.log(p_img);

    var img;

    //compress image and put to pdf
    //sharp('D:\\Projects\\img\\Pizigani_1367_Chart_10MB.jpg')
    await sharp(p_img)
    .rotate()
    .resize(1200)
    .jpeg({ mozjpeg: true })
    .toBuffer()
    .then( data => {
        //console.log(data);
        img = Buffer.from(data);
    })
    .catch( err => {
        console.log(err);
    });

    return img;

};

module.exports = mySharpImg;